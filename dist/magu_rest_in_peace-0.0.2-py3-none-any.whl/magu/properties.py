# Database
DATABASE_HOST="localhost"
DATABASE_USER="root"
DATABASE_PASSWORD="root"

# Server
SERVER_HOST="localhost"
SERVER_PORT=8000
SERVER_ADDRESS = f"http://{SERVER_HOST}:{SERVER_PORT}"

# Authentication
SECRET_KEY="secret_key_123"
